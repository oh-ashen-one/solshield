module.exports=[56833,(a,b,c)=>{}];

//# sourceMappingURL=packages_web__next-internal_server_app_patterns_page_actions_8aad7aa2.js.map