module.exports=[568,a=>{a.v("/_next/static/media/favicon.0b3bf435.ico")},54450,a=>{"use strict";let b={src:a.i(568).default,width:256,height:256};a.s(["default",0,b])}];

//# sourceMappingURL=packages_web_src_app_c3ee301a._.js.map