var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/v1/audit/route.js")
R.c("server/chunks/[externals]_next_dist_03fe02e0._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_71111530.js")
R.c("server/chunks/packages_web__next-internal_server_app_api_v1_audit_route_actions_e8e038ed.js")
R.m(88470)
module.exports=R.m(88470).exports
