module.exports=[36773,(a,b,c)=>{}];

//# sourceMappingURL=packages_web__next-internal_server_app_page_actions_d0119829.js.map