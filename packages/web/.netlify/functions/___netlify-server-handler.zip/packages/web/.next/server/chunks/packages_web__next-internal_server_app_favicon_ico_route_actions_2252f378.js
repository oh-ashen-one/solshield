module.exports=[23567,(e,o,d)=>{}];

//# sourceMappingURL=packages_web__next-internal_server_app_favicon_ico_route_actions_2252f378.js.map