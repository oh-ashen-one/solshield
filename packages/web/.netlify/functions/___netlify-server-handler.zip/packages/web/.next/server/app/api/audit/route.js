var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/audit/route.js")
R.c("server/chunks/[root-of-the-server]__535126bd._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/packages_web__next-internal_server_app_api_audit_route_actions_8df4a368.js")
R.m(44656)
module.exports=R.m(44656).exports
