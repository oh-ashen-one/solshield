var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[externals]_next_dist_03fe02e0._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_4b8e384c.js")
R.c("server/chunks/packages_web__next-internal_server_app_favicon_ico_route_actions_2252f378.js")
R.m(99501)
module.exports=R.m(99501).exports
