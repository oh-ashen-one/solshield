module.exports=[24176,(a,b,c)=>{}];

//# sourceMappingURL=packages_web__next-internal_server_app__global-error_page_actions_7e8b93b2.js.map