module.exports=[6981,(a,b,c)=>{}];

//# sourceMappingURL=packages_web__next-internal_server_app__not-found_page_actions_47bb0316.js.map